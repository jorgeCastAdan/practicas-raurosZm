package rauroszm.practicas;

import java.util.HashSet;
import java.util.Scanner;

/**
 * Clase Programa que contiene el main y por tanto la ejecución del programa
 * @author Jorge Castellanos Adan
 * @version 05/02/2025
 */
public class Programa {
	private static HashSet<Paquete> paquetes = new HashSet<>();
	private static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) 
	{
		int opcion = -1;
		
		while(opcion != 0) 
		{
			opcion = menu();
			
			switch (opcion) 
			{			
				case 1:
					System.out.println("OPCION 1: Registrar paquete");
					registrarPaquete();
					break;
				case 2:
					System.out.println("OPCION 2: Listar paquetes\n");
					listarpaquetes();
					break;
				case 3:
					if(paquetes.size() > 0) 
					{
						System.out.println("OPCION 3: Buscar paquete");
						Paquete paqueteBuscado = buscarPaquete(pedirNumSeguimiento());
						if(paqueteBuscado != null)
							System.out.println(paqueteBuscado);
						else
							System.out.println("No se ha encontrado el paquete");
					}
					else
						System.out.println("La lista de paquetes en seguimiento esta vacia");
					break;
				case 4:
					if(paquetes.size() > 0) 
					{
						System.out.println("OPCION 4: Elimiar paquete");
						Paquete paqueteEliminar = buscarPaquete(pedirNumSeguimiento());

						eliminarPaquete(paqueteEliminar);
					}
					else
						System.out.println("La lista de paquetes en seguimiento esta vacia");

					break;
				default:
					System.out.println("\nFin del programa");
			}
		}
		sc.close();
	}

	/**
	 * Trata de eliminar un determinado paquete y que avisa al usuario si el paquete se ha borrado con exito o no
	 * @param paqueteEliminar El Paquete que se quiere eliminar de la colección
	 */
	private static void eliminarPaquete(Paquete paqueteEliminar) {
		if(paquetes.remove(paqueteEliminar))
			System.out.println("Se ha eliminado el paquete con numero de seguimiento["+paqueteEliminar.getNumSeguimiento()+"] con exito");
		else 
			System.out.println("No se ha encontrado un paquete con el numero de seguimiento ["+paqueteEliminar.getNumSeguimiento()+"] registrado");
	}

	/**
	 * Busca un paquete con un determinado numero de seguimiento en una coleccion
	 * @param numSeguimiento Numero de seguimiento del paquete que se quiere buscar
	 * @return Devuelve una instancia de Paquete en caso de encontrar una coincidencia en el numero de seguimiento. Devolverá null en caso contrario
	 */
	private static Paquete buscarPaquete(int numSeguimiento) 
	{
		Paquete paquete = null;
		
		for(Paquete p : paquetes) 
		{
			if(p.getNumSeguimiento() == numSeguimiento)
				paquete = p;
		}
		
		return paquete;
	}

	/**
	 * Recorre la coleccion y muestra al usuario todos los paquetes registrados
	 */
	private static void listarpaquetes() {
		
		if(paquetes.size() > 0) 
		{
			for(Paquete p : paquetes) 
			{
				System.out.println(p);
			}
		}
		else
			System.out.println("La lista de paquetes en seguimiento esta vacia");
		
	}

	/**
	 * Registra una instancia de la clase Paquete en la colección pidiendole al usuario peso, direccion y numero de seguimiento
	 */
	private static void registrarPaquete()
	{
		Paquete paquete = new Paquete();
		int numSeg = 0;
		String direccion = new String();
		double peso = 0.0;
		Boolean noRepetido = false;
		
		System.out.println("Introduce la direccion del paquete: ");
		direccion = sc.nextLine();
		paquete.setDireccionEntrega(direccion);
		
		while(peso <= 0) 
		{
			try 
			{
				sc.reset();
				System.out.println("Introduce el peso del paquete");
				peso = Double.valueOf(sc.nextLine());
			}
			catch(NumberFormatException e) 
			{
				System.err.println("Se tiene que introducir un valor valido para el peso (ni letras ni simbolos)");
			}
			
		}
		paquete.setPeso(peso);
		
		while(numSeg <= 0 || !noRepetido) 
		{
			numSeg = pedirNumSeguimiento();
		
			if(numSeg > 0) 
			{
				paquete.setNumSeguimiento(numSeg);
				
				if(paquetes.add(paquete))
					noRepetido = true;	
				else
					System.err.println("El numero de seguimiento ya esta registrado");
			}
		}
	}

	/**
	 * Pide al usuario un numero de seguimiento de un paquete
	 * @return Devuelve el valor del numero de seguimiento introducido por el usuario. En caso de que no se introduzca un dato valido, devuelve 0
	 */
	static int pedirNumSeguimiento() {
		int numSeg = 0;
		try 
		{
			System.out.println("Introduce el numero de seguimiento del paquete (debe ser unico)");
			numSeg = Integer.valueOf(sc.nextLine());
		}
		catch(NumberFormatException e) 
		{
			System.err.println("Se tiene que introducir un valor valido para el numero de seguimiento (ni letras ni simbolos)");
		}
		return numSeg;
	}

	/**
	 * Muestra las distintas opciones del menu y pide al usuario que introduzca una de las opciones
	 * @return Devuelve un numero comprendido entre el 0 y el 4 que hace referencia a la opcion del menu
	 */
	private static int menu() 
	{
		int opcion = -1;
		
		System.out.println("\nOPCION 1: Registrar paquete"
							+ "\nOPCION 2: Listar paquetes"
							+ "\nOPCION 3: Buscar paquete"
							+ "\nOPCION 4: Eliminar paquete"
							+ "\nSALIR (pulsar 0)");
		
		while(opcion < 0 || opcion > 4) 
		{
			try 
			{
				System.out.println("Indique que opcion del menu quiere seleccionar (0-4): ");
				opcion = Integer.valueOf(sc.nextLine());
				if(opcion < 0 || opcion > 4)
					System.err.println("La opcion tiene que ser un numero entre el 0 y el 4 (ambos incluidos)");
			}
			catch(NumberFormatException e) 
			{
				System.err.println("Se tiene que ingresar un numero.");
			}
		}
		
		return opcion;
	}
}