package rauroszm.practicas;

import java.util.Objects;

/**
 * Clase Paquete de la que hace uso la clase Programa
 * @author Jorge Castellanos Adan
 * @version 05/02/2025
 */
public class Paquete {
	private int numSeguimiento;
	private String direccionEntrega;
	private double peso;
	private int costoEnvio;
	
	public Paquete(int numSeguimiento, String direccionEntrega, double peso) {
		this.numSeguimiento = numSeguimiento;
		this.direccionEntrega = direccionEntrega;
		this.peso = peso;
		calcCostoEnvio();
	}
	
	public Paquete() 
	{
		
	}

	public String getDireccionEntrega() {
		return direccionEntrega;
	}

	public void setDireccionEntrega(String direccionEntrega) {
		this.direccionEntrega = direccionEntrega;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
		calcCostoEnvio();
	}

	public int getNumSeguimiento() {
		return numSeguimiento;
	}
	
	public void setNumSeguimiento(int numSeguimiento) {
		this.numSeguimiento = numSeguimiento;
	}
	
	/**
	 * Le asigna un valor al atributo de costo dependiendo del peso del objeto Paquete
	 */
	private void calcCostoEnvio() {
		if(this.peso <= 5) 
			this.costoEnvio = 10;
		else if(this.peso > 5 && peso < 20)
			this.costoEnvio = 25;
		else
			this.costoEnvio = 50;		
	}

	@Override
	public int hashCode() {
		return Objects.hash(numSeguimiento);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Paquete other = (Paquete) obj;
		return numSeguimiento == other.numSeguimiento;
	}

	@Override
	public String toString() {
		return "Paquete [numSeguimiento=" + numSeguimiento + ", direccionEntrega=" + direccionEntrega + ", peso=" + peso
				+ ", costoEnvio=" + costoEnvio + "€]";
	}
}
